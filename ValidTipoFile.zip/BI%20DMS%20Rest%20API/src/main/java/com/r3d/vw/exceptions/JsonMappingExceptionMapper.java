package com.r3d.vw.exceptions;

import com.fasterxml.jackson.databind.JsonMappingException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.logging.Logger;

@Provider
public class JsonMappingExceptionMapper implements ExceptionMapper<JsonMappingException> {

    private static final Logger LOGGER = Logger.getLogger(JsonMappingExceptionMapper.class.getName());

    @Override
    public Response toResponse(JsonMappingException exception) {
        LOGGER.warning("Error de mapeo JSON: " + exception.getMessage());
        return Response.status(Response.Status.BAD_REQUEST)
                .entity("Estructura de datos inválida.")
                .build();
    }
}
