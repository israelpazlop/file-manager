package com.r3d.vw.rest;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.validation.constraints.NotNull;

import com.r3d.vw.model.Usuario;
import com.r3d.vw.token.TokenSesionBean;

@Path(value = "login")
@Consumes(value = MediaType.APPLICATION_JSON)
@Produces(value = {MediaType.APPLICATION_JSON})
public class LoginWebService {
private Logger logger = Logger.getLogger(getClass().getName());
	
	@Inject
	private TokenSesionBean tokenSesionBean;
	
	
	@Context
	private UriInfo uriInfo;

	/*@POST
	@Path(value = "token")
	public Response login(@Valid Usuario usuario) {
		Integer timetoken = getTimeToken(usuario.getEmail(),usuario.getPassword(),usuario.getCodigoReferencia());
		if	(timetoken == 0) {
			return Response.status(Response.Status.UNAUTHORIZED).entity("Ingreso no Autorizado").build();
		}
		return Response.ok().entity(tokenSesionBean.genera(usuario.getEmail(), uriInfo, timetoken)).build();
	}*/
	@POST
	@Path("token")
	public Response login(@Valid Usuario usuario) {
		try {
			Integer timetoken = getTimeToken(
					usuario.getEmail(),
					usuario.getPassword(),
					usuario.getCodigoReferencia()
			);

			if (timetoken == 0) {
				return Response.status(Response.Status.UNAUTHORIZED)
						.entity("Ingreso no Autorizado")
						.build();
			}

			return Response.ok()
					.entity(tokenSesionBean.genera(usuario.getEmail(), uriInfo, timetoken))
					.build();

		} catch (Exception e) {
			logger.severe("Error inesperado en login: " + e.getMessage());
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity("Ha ocurrido un error inesperado.")
					.build();
		}
	}

	
	@GET
	@Path(value = "token")
	public Response login(
			@QueryParam(value = "user") String mail,
			@QueryParam(value = "password") String password
			) {
		
		
		Integer timetoken = getTimeToken(mail,password,"DMS");
		if	(timetoken == 0) {
			return Response.status(Response.Status.UNAUTHORIZED).entity("Ingreso no Autorizado").build();
		}
		return Response.ok().entity(tokenSesionBean.genera(mail, uriInfo, timetoken)).build();
	}
	
	
	public Integer getTimeToken(@NotNull String email,String password, String coderefe) {
		Integer timeToken= 0;
		String workingDir = System.getProperty("url.root.dms");
	 try (InputStream input = new FileInputStream( workingDir + 
	 		"/bin/config/dmsotherConfig.properties")) {

           Properties prop = new Properties();

           // load a properties file
           prop.load(input);
          
          
           if (email.equalsIgnoreCase(prop.getProperty("login.name")) 
        		   && password.equalsIgnoreCase(prop.getProperty("login.password")) 
        		   && coderefe.equalsIgnoreCase(prop.getProperty("login.codigoReferencia"))
        		   ) {
        	   
        	  
                   
        		   String timeTokenStr = prop.getProperty("TimeToken", "0");
        		   timeToken = Integer.parseInt(timeTokenStr);
           
             
           }
           else {
        	   
        	   timeToken = 0;
           }
           
         

       } catch (IOException ex) {
    	   logger.log(Level.WARNING, "Error al leer las propiedades:  {0}"  , ex.getMessage());
           
       }
	 
	
	 return timeToken;
	}
	
}
