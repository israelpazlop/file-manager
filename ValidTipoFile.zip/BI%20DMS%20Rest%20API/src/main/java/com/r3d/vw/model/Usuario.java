package com.r3d.vw.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public class Usuario {


	@NotNull
	@Size(min = 1, max = 50)
	private String email;
	
	@NotNull
	@Size(min = 2, max = 100)
	private String password;
	
	@NotNull
	@Size(max = 8)
	private String codigoReferencia;
	
	private String rol;

	private String firstLastName;
	
	private String name;
	
	private String nombreProyecto;
	
	private String secondLastName;
	
	private String secRolEntidadLista;
	private String projectEntidadLista;

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCodigoReferencia() {
		return codigoReferencia;
	}
	public void setCodigoReferencia(String codigoReferencia) {
		this.codigoReferencia = codigoReferencia;
	}
	public String getRol() {
		return rol;
	}
	public void setRol(String rol) {
		this.rol = rol;
	}
	public String getFirstLastName() {
		return firstLastName;
	}
	public void setFirstLastName(String firstLastName) {
		this.firstLastName = firstLastName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNombreProyecto() {
		return nombreProyecto;
	}
	public void setNombreProyecto(String nombreProyecto) {
		this.nombreProyecto = nombreProyecto;
	}
	public String getSecondLastName() {
		return secondLastName;
	}
	public void setSecondLastName(String secondLastName) {
		this.secondLastName = secondLastName;
	}
	public String getSecRolEntidadLista() {
		return secRolEntidadLista;
	}
	public void setSecRolEntidadLista(String secRolEntidadLista) {
		this.secRolEntidadLista = secRolEntidadLista;
	}
	public String getProjectEntidadLista() {
		return projectEntidadLista;
	}
	public void setProjectEntidadLista(String projectEntidadLista) {
		this.projectEntidadLista = projectEntidadLista;
	}

	
}
