package com.r3d.vw.token;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.crypto.spec.SecretKeySpec;
import javax.inject.Singleton;


import io.jsonwebtoken.Jwts;

@Singleton
public class GeneradorLlave {

	private Logger logger = Logger.getLogger(getClass().getName());
	
	
	public Key generar( ) {
		return generar("simplekey");
	}
	
	public Key generar(String llave) {
		return new SecretKeySpec(llave.getBytes(), 0, llave.getBytes().length, "DES");
	}
	
	public String digest(String textoPlano)  {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			messageDigest.update(textoPlano.getBytes(StandardCharsets.UTF_8));
			byte[] passwordDigest = messageDigest.digest();
			return new String(Base64.getEncoder().encode(passwordDigest));
		} catch (Exception exception) {
			logger.log(Level.SEVERE, "Exception codificando. {0} ", exception.getMessage());
			return "";

		}
	}
	
	public String getEmailFromToken(String token) {
		return Jwts.parser().setSigningKey(this.generar())
				.parseClaimsJws(token.substring("Bearer".length()).trim()).getBody().get("sub").toString();
	}
}
