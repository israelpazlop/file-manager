package com.r3d.vw.token;


import java.security.Key;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;



import javax.inject.Inject;
import javax.inject.Singleton;

import javax.ws.rs.core.UriInfo;



import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Singleton
public class TokenSesionBean {

	@Inject
	private GeneradorLlave generadorLlave;
	

	
	public String genera(String usuario, UriInfo uriInfo, Integer timetoken) {
		Key key = generadorLlave.generar();
		return Jwts.builder()
				.setSubject(usuario)
				.setIssuer(uriInfo.getAbsolutePath().toString())
				.setIssuedAt(new Date())
				.setExpiration(toDate(LocalDateTime.now().plusMinutes(timetoken.longValue())))
				.signWith(SignatureAlgorithm.HS512, key)
				.compact();
	}
	
	private Date toDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

}
