package com.r3d.vw.config;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath(value = "webservice")
public class AplicacionRest extends Application {

}
