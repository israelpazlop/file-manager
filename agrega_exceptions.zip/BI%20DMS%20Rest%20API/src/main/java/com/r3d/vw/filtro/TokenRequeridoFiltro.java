package com.r3d.vw.filtro;

import java.io.IOException;
import java.security.Key;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Priority;
import javax.inject.Inject;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import com.r3d.vw.token.GeneradorLlave;

import io.jsonwebtoken.Jwts;

@Provider
@TokenRequerido
@Priority(value = Priorities.AUTHENTICATION)
public class TokenRequeridoFiltro implements ContainerRequestFilter {

	private Logger logger = Logger.getLogger(getClass().getName());
	
	@Inject
	private GeneradorLlave generadorLlave;

	public void filter(ContainerRequestContext containerRequestContext) throws IOException {
		String authorizationHeader = containerRequestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
		if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
			
			logger.log(Level.INFO, "autorizacion no valida: {0}" , authorizationHeader);
			throw new  NotAuthorizedException("token de autorizacion no provista");
		}
		String token = authorizationHeader.substring("Bearer".length()).trim();
		try {
			Key key = generadorLlave.generar();
			Jwts.parser().setSigningKey(key).parseClaimsJws(token);
			logger.log(Level.INFO, "token valido: {0}", token);
			
		} catch (Exception e) {
			containerRequestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
		}
	}

	
}
