package com.r3d.vw.servicio;


import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;




@Stateless
@TransactionManagement(value = TransactionManagementType.CONTAINER)
public class ValidacionServicio {

	private Logger logger = Logger.getLogger(getClass().getName());
	
	


	public static final String REGEXNOMBREARCHIVO="(\\d{3,10})(20\\d{2}|19\\d{2})(\\d{2})(\\d{2})(.zip)";
	
	
	
	public Boolean verificarNombreArchivo(String nombreArchivo) {
		//verificar si el nombre del archivo corresponde
		 Pattern pattern = Pattern.compile(ValidacionServicio.REGEXNOMBREARCHIVO, Pattern.CASE_INSENSITIVE);
		 Matcher matcher = pattern.matcher(nombreArchivo);
		 if(!matcher.find()) {
			 return false;
		 }

		 logger.log(Level.INFO, nombreArchivo);
		 
		 

		 String fecha = nombreArchivo.substring(nombreArchivo.length()-12,nombreArchivo.length()-4);


		 //verificar la fecha
		 Integer anio=Integer.parseInt(fecha.substring(0,4));
		 Integer mes=Integer.parseInt(fecha.substring(4,6));
		 Integer dia=Integer.parseInt(fecha.substring(6,8));
		 
		 mes--;
		 Calendar calendar=Calendar.getInstance();
		 return (anio==calendar.get(Calendar.YEAR) 
				 && mes==calendar.get(Calendar.MONTH)
				 && dia==calendar.get(Calendar.DAY_OF_MONTH));
			 
		 
		 
	}
	
	
}
