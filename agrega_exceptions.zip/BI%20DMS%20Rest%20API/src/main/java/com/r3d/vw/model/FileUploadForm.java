package com.r3d.vw.model;

import javax.validation.constraints.NotNull;
import javax.ws.rs.FormParam;

import org.jboss.resteasy.annotations.providers.multipart.PartType;


public class FileUploadForm {


	
	@NotNull
	private byte[] informacion;
	
	@NotNull
	private String nombre;
	
	
	private Long selectedFolder;
	
	public byte[] getInformacion() {
		return informacion;
	}
	
	@FormParam(value = "selectedFile")
	@PartType(value = "application/octet-stream")
	public void setInformacion(byte[] informacion) {
		this.informacion = informacion;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	@FormParam(value = "fileName")
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Long getSelectedFolder() {
		return selectedFolder;
	}
	@FormParam(value = "selectedFolder")
	public void setSelectedFolder(Long selectedFolder) {
		this.selectedFolder = selectedFolder;
	}


}
