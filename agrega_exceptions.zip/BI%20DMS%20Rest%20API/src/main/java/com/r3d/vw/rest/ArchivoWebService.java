package com.r3d.vw.rest;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import java.util.logging.Level;


import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.Consumes;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;



import org.jboss.resteasy.annotations.providers.multipart.MultipartForm;

import com.r3d.vw.filtro.TokenRequerido;
import com.r3d.vw.model.FileUploadForm;
import com.r3d.vw.servicio.ValidacionServicio;

import com.r3d.vw.validacion.ValidacionArchivoSesionBean;




@Path(value = "archivo")
@Produces(value = {MediaType.APPLICATION_JSON})
public class ArchivoWebService {
	
	private Logger logger = Logger.getLogger(getClass().getName());
	
	@Inject
	private ValidacionArchivoSesionBean validacionArchivoSingleton;
	
	
	@Inject
	private ValidacionServicio validacionServicios;
	
	@POST
	@Consumes("multipart/form-data")
	@TokenRequerido
	public Response cargaArchivo(@MultipartForm @Valid FileUploadForm fileUploadForm, @Context HttpHeaders headers) throws   IOException {
		
		String directoryIN = "";
		String workingDir = System.getProperty("url.root.dms");
		 try (InputStream input = new FileInputStream(workingDir
					+ "/bin/config/dmsotherConfig.properties")) {

	            Properties prop = new Properties();

	            // load a properties file
	            prop.load(input);

	            directoryIN = prop.getProperty("directory.in");
	            
	            // get the property value and print it out
	            
	            logger.log(Level.INFO, prop.getProperty("directory.in"));
	       

	        } catch (IOException ex) {	            
	            logger.log(Level.WARNING, ex.getMessage());
	        }
		
		if(fileUploadForm.getNombre().contains(".zip") && Boolean.TRUE.equals(!validacionServicios.verificarNombreArchivo(fileUploadForm.getNombre()))) {			
			logger.log(Level.INFO, "Codigo: 103, Nombre de Archivo Invalido {0} ", fileUploadForm.getNombre());
			return Response.status(Response.Status.BAD_REQUEST).entity("Codigo: 103, Nombre de Archivo Invalido "+fileUploadForm.getNombre()).build();	
		}
		
		//comprobar si queda espacio disponible en la unidad de disco
		if(new File("/").getFreeSpace()<fileUploadForm.getInformacion().length) {
			logger.log(Level.INFO, "Codigo: 107, Espacio no disponible en disco {0} " , fileUploadForm.getNombre() );			
			return Response.status(Response.Status.BAD_REQUEST).entity("Codigo: 107, Espacio no disponible en disco "+fileUploadForm.getNombre()).build();
		}
		UUID uuid = UUID.randomUUID();
		java.nio.file.Path path = Paths.get(System.getProperty("jboss.server.temp.dir") + File.separator + uuid.toString());
		Files.copy(new ByteArrayInputStream(fileUploadForm.getInformacion()), path, StandardCopyOption.REPLACE_EXISTING);
		
		
		
		List<String> validacion = validacionArchivoSingleton.valida(
				path,
				Files.newInputStream(path),
				fileUploadForm.getNombre()
				);
		if(validacion==null) {
			
			logger.log(Level.INFO, "Codigo: 104, Numero de Archivos invalido " );	
			return Response.status(Response.Status.BAD_REQUEST).entity("Codigo: 104, Numero de Archivos invalido").build();
		}
		else if (!validacion.isEmpty()) {
			Files.delete(path);
			return Response.status(Response.Status.BAD_REQUEST).entity(validacion).build();			
		}
		
		
		
			
			
			java.nio.file.Path desino = Paths.get(directoryIN + fileUploadForm.getNombre());
			
			
			
			String mensaje="";
			
				if(fileUploadForm.getNombre().split("\\.")[1].trim().toLowerCase().equalsIgnoreCase("zip")) {
					
					try {
						Files.copy(path, desino, StandardCopyOption.REPLACE_EXISTING);
						
						logger.log(Level.INFO,"Copia: del archivo a - {0} " , desino  );	
						
					}catch(Exception e) {
						mensaje=e.getMessage();
					}
				}else {

						try {
							
							Files.copy(path, desino, StandardCopyOption.REPLACE_EXISTING);
							
							mensaje=String.format("Se substituyo el archivo %s",fileUploadForm.getNombre());
						}catch(FileAlreadyExistsException e) {
								mensaje="Codigo: 105, Archivo ya existe en "+ directoryIN;
								logger.log(Level.WARNING, e.getMessage());
								
						}catch(Exception e) {
							mensaje=e.getMessage();
						}

				}
			
			Files.delete(path);
			return Response.ok().entity(mensaje).build();
	}
	
}
