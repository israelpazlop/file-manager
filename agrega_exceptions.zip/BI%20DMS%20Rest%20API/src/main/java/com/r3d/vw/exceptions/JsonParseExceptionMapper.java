package com.r3d.vw.exceptions;
import com.fasterxml.jackson.core.JsonParseException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.logging.Logger;

@Provider
public class JsonParseExceptionMapper implements ExceptionMapper<JsonParseException> {

    private static final Logger LOGGER = Logger.getLogger(JsonParseExceptionMapper.class.getName());

    @Override
    public Response toResponse(JsonParseException exception) {
        LOGGER.warning("Error de parseo JSON: " + exception.getMessage());
        return Response.status(Response.Status.BAD_REQUEST)
                .entity("Solicitud malformada. Verifica el formato del JSON.")
                .build();
    }
}
