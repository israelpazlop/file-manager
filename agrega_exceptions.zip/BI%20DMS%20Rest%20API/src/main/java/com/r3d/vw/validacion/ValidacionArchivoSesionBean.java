package com.r3d.vw.validacion;



import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import javax.annotation.PostConstruct;


import javax.validation.constraints.NotNull;






public class ValidacionArchivoSesionBean {


	
private Logger logger = Logger.getLogger(getClass().getName());
	
	
	
	@PostConstruct
	public void inicio() {
		// Do nothing
	}

	public List<String> valida(@NotNull java.nio.file.Path path,
			@NotNull InputStream inputStream,
			@NotNull String nombre
			) throws  IOException{
		
		
		if ("zip".equalsIgnoreCase(nombre.split("\\.")[1].trim().toLowerCase())) {
			return zip(path,inputStream);
		}else {
						
			return new LinkedList<>();
		}
		
		
	}
	
	
	private List<String> zip(java.nio.file.Path path,
			InputStream inputStream
			) throws  IOException {
		ZipFile zf=new ZipFile(path.toFile());
		Integer contador=0;

		ZipInputStream zis = new ZipInputStream(inputStream);
		ZipEntry entry;
		List<String> validaciones = null;
        // while there are entries I process them
		try {
			while ((entry = zis.getNextEntry()) != null) {
				contador++;
				 
				 logger.log(Level.INFO, "entry: {0} "  , entry.getName());
	             
			}
			// Se forza a validar el archivo debe traer 10 archivos
			if(contador != 10) {
				zf.close();
				return validaciones;
			}
			validaciones = new ArrayList<>();
			
		}catch(Exception e) {
			logger.log(Level.WARNING, "Error al leer las propiedades:  {0} "  , e.getMessage());
		}finally {
			zf.close();
		}
		
		return validaciones;
	}
	
	
}
